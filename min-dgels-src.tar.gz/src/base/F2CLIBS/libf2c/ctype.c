#define My_ctype_DEF
#include "ctype.h"
